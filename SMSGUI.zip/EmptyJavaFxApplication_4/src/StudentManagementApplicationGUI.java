// **********************************************
// Title: Database project
// Author: Alengta Jernigan
// Course Section: CMIS201-ONL1 (Seidel) Fall 2023
// File: StudentManagementApplication.java
// Description: The prototype of the Database project.
//Store and manage student enrollment and tuition balance at a university
// **********************************************
import java.io.FileWriter;
import java.io.IOException;

import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Button;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.RadioButton;
import javafx.scene.control.TextField;
import javafx.scene.control.ToggleGroup;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.stage.Stage;


public class StudentManagementApplicationGUI extends Application {
     private  double tuitionBalance = 0;
     private static final double costOfCourse = 600;
     private GridPane grid;
     private ComboBox combBox1;
     private ComboBox combBox2;
     private RadioButton maleRb;
     private RadioButton femaleRb;
     private HBox hBoxDisplay;
     
        public static final String BLANK = "";

	public static final String OUTPUT_FILE_PATH = "Student.txt";

	@Override
	public void start(Stage stage) {
		stage.setTitle("Student Management System");

		GridPane grid = new GridPane();
		grid.setAlignment(Pos.CENTER);
		grid.setHgap(10);
		grid.setVgap(10);
		grid.setPadding(new Insets(25, 25, 25, 25));
                 
                //Main Title
		Label sceneTitle = new Label("Student Management System");
		sceneTitle.setFont(Font.font("Tahoma", FontWeight.NORMAL, 20));
		sceneTitle.setStyle("-fx-text-fill: #006400;");
		grid.add(sceneTitle, 2, 0, 2, 1);
                
                //Student Information
                //Student   ID
                
		Label studentIdLabel = new Label("Student ID: "
                        + "E.g 1001");
		grid.add(studentIdLabel, 0, 1);

		TextField studentIdField = new TextField();
		grid.add(studentIdField, 1, 1);
                
                 //Student   Name
		Label studentNameLabel = new Label("Student Name:");
		grid.add(studentNameLabel, 2, 1);

		TextField studentNameField = new TextField();
		grid.add(studentNameField, 3, 1);
                
            //Drop down list for GradYear
            ComboBox<Object> combBox1 = new ComboBox<>();

              //getItems returns the ObservableList object which you can add items to
              combBox1.getItems().add("Freshman");
              combBox1.getItems().add("Sophmore");
              combBox1.getItems().add("Junior");
              combBox1.getItems().add("Senior");
              
              //Set a default value
              combBox1.setPromptText("Select Student Grade Year");
               grid.add(combBox1, 5, 2);
               
               //Drop down list for courses and enter courses
               ComboBox<Object> combBox2 = new ComboBox<>();
                combBox2.getItems().addAll(
                        "ENGLISH 101",
                        "MATH 185",
                        "ANTH 101",
                        "PSY 101",
                        "CHEM 101",
                        "CMIS 106",
                        "BSCI 240",
                        "HLTH 150"
                );
                combBox2.setEditable(true);
                 //Set a default value
                combBox2.setPromptText("Select Courses Or Add Course By Typing In Box ");
                
                grid.add(combBox2, 5, 3);
                combBox2.setPrefSize(300, 20);
                
                 //Student   Gender
		Label sexLabel = new Label("Sex");
		grid.add(sexLabel, 4, 1);

		RadioButton maleRb = new RadioButton("Male");
		RadioButton femaleRb = new RadioButton("Female");
		ToggleGroup sexGroup = new ToggleGroup();
		maleRb.setToggleGroup(sexGroup);
		femaleRb.setToggleGroup(sexGroup);
		HBox sexSelector = new HBox(10, maleRb, femaleRb);
		grid.add(sexSelector, 5, 1);
                        
                //Studnet Tuition  Calculation
		Label courseNumberLabel = new Label("How many Courses Student Enrolled in?");
		grid.add(courseNumberLabel, 0, 2);

		TextField courseNumberField = new TextField();
		grid.add(courseNumberField, 1, 2);

		Label email = new Label("Student Email:");
		grid.add(email, 2, 2);

		TextField emailField = new TextField();
		grid.add(emailField, 3, 2);

		Label noteLabel = new Label("Note:");
		grid.add(noteLabel, 0, 3);

		TextField noteField = new TextField();
		grid.add(noteField, 0, 4, 6, 1);

		Label totalLabel = new Label("Total Tuition:");
		grid.add(totalLabel, 4, 5);

		TextField totalField = new TextField();
		totalField.setEditable(false);
		grid.add(totalField, 5, 5);

		Button totalButton = new Button("Total");
		totalButton.setPrefWidth(500);
		Button saveButton = new Button("Save");
		saveButton.setPrefWidth(500);
		Button clearButton = new Button("Clear");
		clearButton.setPrefWidth(500);
		Button closeButton = new Button("Close");
		closeButton.setPrefWidth(500);

		HBox hBoxDisplay = new HBox(totalButton, saveButton, clearButton, closeButton);
		grid.add(hBoxDisplay, 0, 6, 6, 1);

		totalButton.setOnAction(actionEvent -> {
			String studentId = studentIdField.getText();
			String studentName = studentNameField.getText();
			RadioButton sexSelection = (RadioButton) sexGroup.getSelectedToggle();
			String sex = (sexSelection == null) ? "" : sexSelection.getText();
			String cNumber = courseNumberField.getText();
			String emailF = emailField.getText();
                        
			if (BLANK.equals(studentId) || BLANK.equals(studentName) || BLANK.equals(sex) || BLANK.equals(cNumber)
					|| BLANK.equals(emailF)
                                )
                                {
				this.alert("Error", "Please enter all input values!", AlertType.ERROR);
				return;
			} else {
				double courseNumber = Double.parseDouble(cNumber);
				//double calTuition = Double.parseDouble(Tuition);
				double total = courseNumber * costOfCourse;
				totalField.setText(String.valueOf(total));
				
			}

		});

		saveButton.setOnAction(actionEvent -> {
			String studentId = studentIdField.getText();
			String studentName = studentNameField.getText();
			RadioButton sexSelection = (RadioButton) sexGroup.getSelectedToggle();
			String sex = sexSelection.getText();
			String cNumber = courseNumberField.getText();
			String emailF = emailField.getText();
			if (BLANK.equals(studentId) || BLANK.equals(studentName) || BLANK.equals(sex) || BLANK.equals(cNumber)
					|| BLANK.equals(emailF)
                                ) {
				this.alert("Error", "Please enter all input values!", AlertType.ERROR);
				return;
			} else {
				double java = Double.parseDouble(cNumber);
				//double cpp = Double.parseDouble(cppScore);
				double total = tuitionBalance + costOfCourse;
				totalField.setText(String.valueOf(total));

				try {
					FileWriter writer = new FileWriter(OUTPUT_FILE_PATH, true);
					writer.write(studentId + "," + studentName + "," + sex + "," + cNumber + "," + emailF + ","
							+ total + "\n");
					writer.close();
					this.alert("Success", "Record saved successfully", AlertType.INFORMATION);
				} catch (IOException e) {
					e.printStackTrace();
				}

			}

		});

		clearButton.setOnAction(actionEvent -> {
			studentIdField.setText(BLANK);
			studentNameField.setText(BLANK);
			courseNumberField.setText(BLANK);
			emailField.setText(BLANK);
			noteField.setText(BLANK);
			totalField.setText(BLANK);
			sexGroup.getSelectedToggle().setSelected(false);
                        combBox1.getItems().clear();
                        combBox2.getItems().clear();
		});

		closeButton.setOnAction(actionEvent -> {
			System.exit(0);
		});

		Scene scene = new Scene(grid, 1100, 500);
		stage.setScene(scene);

		stage.show();
	}

	public void alert(String title, String message, AlertType alertType) {
		Alert alert = new Alert(alertType);
		alert.setTitle(title);
		alert.setHeaderText(null);
		alert.setContentText(message);
		alert.showAndWait();
	}

	public static void main(String[] args) {
		launch(args);
	}
}