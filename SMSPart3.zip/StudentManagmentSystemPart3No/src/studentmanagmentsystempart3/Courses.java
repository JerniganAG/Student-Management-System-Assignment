
package studentmanagmentsystempart3;

/**
 *
 * @author aleng
 */
public class Courses {
    private String courseNum, courseName;
    private Integer credits, section;

    //Default constructor
     public Courses() {
        this.courseNum = " No Entry";
        this.courseName = "No Entry";
        this.credits = 0;
        this.section = 0;
    }

    //constructor with 4 parameters courseNum,courseName, credits, section
    public Courses(String courseNum, String courseName, int credits, int section) {
        this.courseNum = courseNum;
        this.courseName = courseName;
        this.credits = credits;
        this.section = section;
    }
    //get and set courseNum
    public String getCourseNum() {
        return courseNum;
    }
    //get and set courseNum
    public void setCourseNum(String courseNum) {
        this.courseNum = courseNum;
    }
    //get and set courseName
    public String getCourseName() {
        return courseName;
    }
    //get and set courseName
    public void setCourseName(String courseName) {
        this.courseName = courseName;
    }
    //get and set credits
    public int getCredits() {
        return credits;
    }
    //get and set credits
    public void setCredits(int credits) {
        this.credits = credits;
    }
    //get and set Section
    public int getSection() {
        return section;
    }
    //get and set Section
    public void setSection(int section) {
        this.section = section;
    }
    
    //toString show all variables
    @Override
    public String toString() {
        return "Courses{" + "courseNum=" + courseNum + ", courseName=" + courseName + ", credits=" + credits + ", section=" + section + '}';
    }
    //equals check either course name or number
    //and the credits and section is same and return true
    public boolean equals(Courses obj){
        return courseName.equals(obj.courseName) ||
                courseNum.equals(obj.courseNum) &&
                credits ==obj.credits &&
                section==obj.section;
    }
}
