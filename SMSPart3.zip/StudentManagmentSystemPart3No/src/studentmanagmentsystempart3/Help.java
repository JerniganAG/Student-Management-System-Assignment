
package studentmanagmentsystempart3;
class Help {
     public static void about() {
        System.out.println("""
                                 This Student Managment System allows Admins to create new students to enroll in courses at a university.
                                 At the main menu there are 11 options and user must type in integer in console to select option before using SMS. 
                                 To get start option 1 will add new students and option 7 will add courses.
                                 """);
    
}
     }
  