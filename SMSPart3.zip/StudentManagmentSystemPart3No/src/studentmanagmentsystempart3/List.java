
package studentmanagmentsystempart3;

import java.util.ArrayList;
import java.util.LinkedList;

/**
 *extends Student class to access all Student methods in List class
 * @author aleng
 */
public class List extends Student {
    LinkedList<Student> studentsList;
    private int size;
    
    //Default constructor
    public List(){
        studentsList = new LinkedList();
        size = 0;
    }
    //addstudent
    //New student object
    //Object of type student is passed as parameter, if object exits in the list
    //No adding object return false or return true after adding the object to list
    public boolean addStudent(Student student){
     for (int i=0; i < size; i++){
         //check inside the list if the student idNum exisits
         if(studentsList.get(i).equals(student))
             //not found idNum return false
             return false;
     }  
     //add student to list return true
     studentsList.add(student);
     size++;
     return true;
    }
     //delectStudent
     //delectStudent delectes a student object from the studentList
     //idNum of the Student is passed as paramenter
     //if the object is not found in the studentList will return false does not exists
     //else the method returns true, after delecting the object
     
     public boolean deleteStudent(int idNum){
         for (int i=0; i < size; i++){
         //check inside the list if the student idNum exisits
         if(studentsList.get(i).getIdNum() ==idNum){
             studentsList.remove(i);
             size--;
             return true;
         }
         }
             //student id not found idNum return false
             return false;
        //searchStudent     
     }//search the studentsList by idNum passed as a parameter.
     //If object is found the location is returned in the StudentsList, else return -1
     public int searchStudent(int idNum){
         //go through all student loop
         for(int i=0; i < size; i++){
          //check inside the list if the student idNum index
         if(studentsList.get(i).getIdNum() ==idNum){
             return i;
         }
         }
         //if not found return -1
         return -1;
     }
    public boolean isEmpty(){return size ==0;}
    public int listSize(){return size;}
    //getStudent
    //getStudent int type parameter found at index and returns 
    //the object type of student in studentsList at location index
    public Student getStudent(int index){
        //use the LinkList get method
    return studentsList.get(index);}
    
    //addCourse uses object of type course as the first parameter and idNum second parameter
    //To add a course
    //student object with specific idNum exists in StudentsList
    //coursee not found in coursesRegisteredlist
    //credits not exceed 18
    //course add return true, else return false
    public boolean addCourse(Courses nCourse, int idNum){
        //get the location index of student by call searchStudent() method
        int index = searchStudent(idNum);
        //if index equal -1 return false mean no student found
        //to count the total credits
            int sumCredits = 0;
        if (index == -1)
            return false;
        else{
            //get the size of coursesRegistered from the getStudent(idNum)
            int sizeCourse = getStudent(index).getCoursesRegistered().size();
            
            for(int i =0; i < sizeCourse; i++){
            //get the course from the courses registered list
                 Courses courses = (Courses)getStudent(index).getCoursesRegistered().get(i);
                if(courses.equals(nCourse))
                    return false;
                else{
                    //sum of course credits
                   sumCredits = courses.getCredits();
                }
                if(sumCredits > 18)
                    return false;
        
            }
    }
        if(sumCredits + nCourse.getCredits() > 18)
            return false;
        getStudent(index).getCoursesRegistered().add(nCourse);
        return true;
}
    //delectCourse uses an object type course as the first parameter and idNum second
    //Course must be exists in the list and student exists in student list to be delected
    public boolean delectCourse(Courses dCourse, int idNum){
        int index = searchStudent(idNum);
        if(index == -1)
            return false;
        else{
            //get all course of this student
            ArrayList coursesList = getStudent(index).getCoursesRegistered();
            for(int i = 0; i < coursesList.size(); i++){
                //get the course by the index
                Courses courses = (Courses)getStudent(index).getCoursesRegistered().get(i);
                if(courses.equals(dCourse)){
                    //not need for courseName
                    //save course name before remove it
                    coursesList.remove(i);
                    //return true
                    return true;
                }
                
            }
        }
        //not found course
        //return false
        System.out.println(" This course number "
        + dCourse.getCourseNum()+ " and course name "
                + dCourse.getCourseName() + " not available!"  );
                
                
        return false;
    }
    //print student details
//accepts idNum of student parameter and print stduent information and courses registered
// print idNum, firstName, lastName, email, gender
    public void printStudentDetails(int idNum){
        int index = searchStudent(idNum);
        if(index != -1){
            Student student = getStudent(index);
            System.out.println("Student id = " + student.getIdNum() +
            "\nStudent full name =" + student.getFirstName()+ ""+student.getLastName()+
            "\nStudent email = " + student.getEmail()+
            "\nStudent gender = " + student.getGender());
            student.printCoursesRegistered();
        }
        else
            System.out.println("Student with id number = " +idNum+ "not found");
        }
    }


