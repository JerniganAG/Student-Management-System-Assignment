
package studentmanagmentsystempart3;

import java.io.Serializable;
import java.util.ArrayList;

/**
 *
 * @author aleng
 */
public class Student extends Help {
   private long idNum;
   private String firstName, lastName, email;
   private char gender;
   private ArrayList <Courses>coursesRegistered;
   
   //Default constructor
    public Student(){
       this.idNum = 0;
       this.firstName = "No Entry";
       this.lastName = "No Entry";
       this.email = "No Enrty";
       this.gender = 'N';
       coursesRegistered = new ArrayList();
    }
  
    //constructor with 5 parameters idNum, firstName, lastName, email, gender
   public Student(long idNum, String firstName, String lastName, String email, char gender){
       this.idNum = idNum;
       this.firstName = firstName;
       this.lastName = lastName;
       this.email = email;
       this.gender = gender;
       coursesRegistered = new ArrayList();
   }
   //get and set idNum
    public long getIdNum() {
        return idNum;
    }
    //get and set idNum
    public void setIdNum(long idNum) {
        this.idNum = idNum;
    }
    //get and set firstName
    public String getFirstName() {
        return firstName;
    }
    //get and set firstName
    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }
    //get and set lastName
    public String getLastName() {
        return lastName;
    }
    //get and set lastName
    public void setLastName(String lastName) {
        this.lastName = lastName;
    }
    //get and set email
    public String getEmail() {
        return email;
    }
    //get and set email
    public void setEmail(String email) {
        this.email = email;
    }
    //get and set gender
    public char getGender() {
        return gender;
    }
     //get and set gender
    public void setGender(char gender) {
        this.gender = gender;
    }
     //get and set coursesRegistered
    public ArrayList getCoursesRegistered() {
        return coursesRegistered;
    }
    //get and set coursesRegistered
    public void setCoursesRegistered(Courses obj) {
      coursesRegistered.add(obj);
    }
    //equals method compare two objects of type student on ther idNum
   public boolean equals(Student obj){
       return this.idNum ==obj.idNum;
   }
   //print CoursesRegistered all courses in the ArrayList
   public void printCoursesRegistered(){
       for(int i=0; i < coursesRegistered.size(); i++){
           System.out.println("Course " + (i+1)+ ":");
           System.out.println(coursesRegistered.get(i).toString()
           +"\n------------------------------------------------------------");
       }
   }
   
}

