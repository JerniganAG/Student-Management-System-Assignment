
// Description: At Menu User has 11 options:
        //(1) addStudent
        //(2) delectStudent
        //(3) searchStudent
        //(4) isEmpty
        //(5) listSize
        //(6) getStudent
        //(7) addCourse
        //(8) delectCourse
        //(9) printStudentDetails
        //(10) About()
        //(0) Exit Program
        //use input for menu
       
// **********************************************
package studentmanagmentsystempart3 ;



import java.util.Scanner;

/**
 *
 * @author aleng
 */
public class StudentManagmentSystemPart3 extends Help {


    
    public static void main(String[] args)  {
        //(1) addStudent
        //(2) delectStudent
        //(3) searchStudent
        //(4) isEmpty
        //(5) listSize
        //(6) getStudent
        //(7) addCourse
        //(8) delectCourse
        //(9) printStudentDetails
        //(10) About()
        //(0) Exit Program
        //use input for menu
        Scanner read = new Scanner(System.in);
        List list = new List();
        int number =0;
        char Answer =' ';
        int index=0;
        int idNum=0;   
    
        do{
            //Show menu option
            System.out.println("----Welcome to Student Managment System----");
            System.out.println("1. Add New Student.\n" +
                               "2. Delete Student.\n" +
                               "3. Find Student.\n" +
                               "4. Check If The List Is Empty.\n" +
                               "5. Number Of Student In List.\n" +
                               "6. Check Student ID Duplication.\n" +
                               "7. Add Course To Student.\n"+
                               "8. Delete Course From Student.\n"+
                               "9. Print All Student Details In List.\n" +
                               "10. About().\n" +
                               "0. Exit Program.");
            System.out.println("\n Choose A Number :");
            number = read.nextInt();
            
            //switch for options
            switch (number){
                //Add New Student
                case 1: 
                    do{
                    System.out.println("Enter Student ID :");
                     idNum=read.nextInt();
                     index = list.searchStudent(idNum);
                     if(index == -1){
          
                    System.out.println(" Enter Student First and Last Name :");
                    String first=read.next(),last=read.next(),email;
                    System.out.println("Enter Student Email :");
                    email=read.next();
                    System.out.println("Enter Student Gender :");
                    char gender = read.next().charAt(0);
                    Student student1 = new Student(idNum,first,last,email,gender);
                    list.addStudent(student1);
                    System.out.println(" Student add to list = " + list.addStudent(student1));
                    System.out.println(" Do you want to add course to " +
                            idNum + " student ? (Y/N) ");
                     Answer=read.next().charAt(0);
                    while (Answer =='Y' || Answer =='y'){// if answer
                    
                    System.out.println("Enter Coure Number :");
                    String courseNum =read.next();
                    System.out.println("Enter course name : ");
                    String  courseName=read.next();
                    System.out.println("Enter course credits and section :");
                    int credit=read.nextInt(), section=read.nextInt();
                    Courses course1 = new Courses(courseNum, courseName, credit, section);
                    System.out.println(" Add course to student Id "
                            + idNum+ "="+list.addCourse(course1, idNum));
                    System.out.println(" Do you want to add another course to " +
                            idNum + " student ? (Y/N) ");
                    Answer=read.next().charAt(0);
                    }
                     }
                     else{
                         System.out.println(" This ID " + idNum + " already exist!! ");
                         System.out.println(" Press r to try again...");
                         read.next();
                         Answer = 'y';
                     }   
                     }while (Answer =='Y' || Answer =='y');{// if answer
                         
                     }
                    break;
                    
                    //Delete Student
                case 2: 
                    
                    do{
                    System.out.print("Enter Student ID : ");
                     idNum=read.nextInt();
                     System.out.print(" Are you sure of delect student ID "
                     + idNum +" ? (Y/N) ");
                     char delete=read.next().charAt(0);
                     if(delete =='Y' || delete =='y')
                         System.out.println(" Student ID "
                         +idNum+ " delete = " + list.deleteStudent(idNum));
                     System.out.println(" Do you want to delete another student ?(Y/N)");
                      Answer=read.next().charAt(0);
                    }while(Answer =='Y' || Answer =='y');
                    break;
                    
                    //Find Student
                case 3:
                   
                    do{
                    System.out.print(" Enter Student ID : ");
                     idNum=read.nextInt();
                     int indexFindStudent = list.searchStudent(idNum);
                     if(indexFindStudent == -1)
                     System.out.print(" Student ID "
                     + idNum + " is not in the list ");
                     else
                         System.out.print(" Student ID "
                            + idNum + " is available, there order number is " +
                                 (indexFindStudent +1 ));
                     System.out.println(" Do you want to search for another student(_Y/N" );
                      Answer=read.next().charAt(0);
                    }while(Answer =='Y' || Answer =='y');
                    break;
                    
                    //Check If The List Is  Empty
                case 4:
                    System.out.println(" Check if the list is empty? "
                    + list.isEmpty());
                    System.out.println(" Press C to continue...");
                    read.next();
                    break;
                    
                    //Number Of Student In List
                case 5:
                    System.out.println(" Students number in the list = "
                    + list.listSize());
                    System.out.println(" Press C to continue...");
                    read.next();
                    break;
                    
                    //Get Student By ID
                case 6: 
                    do{
                    System.out.println(" Enter Student ID = ");
                    idNum = read.nextInt();
                     index = list.searchStudent(idNum);
                    if(index != -1)
                    {
                        list.printStudentDetails(idNum);
                    }else
                        System.out.println(" Student with ID "
                        + idNum + " not found ");
                    System.out.println(" Do you want to try another student? (Y/N) ");
                    Answer = read.next().charAt(0);
            }while(Answer =='Y' || Answer =='y');
                    break;
                    
                    //Add Course To Student
                case 7: 
                    System.out.println(" Enter Student ID = ");
                    idNum = read.nextInt();
                     index = list.searchStudent(idNum);
                    do{
                    
                    if(index != -1)
                    {
                    System.out.println("Enter Coure Number :");
                    String courseNum =read.next();
                    System.out.println("Enter course name : ");
                    String  courseName=read.next();
                    System.out.println("Enter course credits and section :");
                    int credit=read.nextInt(), section=read.nextInt();
                    Courses course1 = new Courses(courseNum, courseName, credit, section);
                    System.out.println(" Add course to student Id "
                            + idNum+ "="+list.addCourse(course1, idNum));
                    System.out.println(" Do you want to add another course to " +
                            idNum + " student ? (Y/N) ");
                    Answer=read.next().charAt(0);
                    }else{
                         System.out.println(" Student with ID "
                        + idNum + " not found ");
                          System.out.println(" Press c to continue and Try again... ");
                          read.next();
                          Answer = 'y';
                    }
                     
                    }while(Answer =='Y' || Answer =='y');
                    break;
                    
                    //Delect Course From Student
                case 8: 
                    System.out.println(" Enter Student ID = ");
                    idNum = read.nextInt();
                     index = list.searchStudent(idNum);
                    do{
                    
                    if(index != -1)
                    {
                        //take course details courseName, courseNum, credits, section
                    System.out.println("Enter Coure Number :");
                    String courseNum =read.next();
                    System.out.println("Enter course name : ");
                    String  courseName=read.next();
                    System.out.println("Enter course credits and section :");
                    int credit=read.nextInt(), section=read.nextInt();
                    //create course obj
                    Courses course1 = new Courses(courseNum, courseName, credit, section);
                    //delect course
                    System.out.println(course1.toString() 
                            + " \n Are you sure you want to delect this course? (Y/N) ");
                    Answer=read.next().charAt(0);
                    if(Answer =='Y' || Answer =='y')
                    System.out.println(" Delect course to student Id "
                            + idNum+ "="+list.delectCourse(course1, idNum));
                    
                    System.out.println(" Do you want to delete another course to " +
                            idNum + " student? (Y/N) ");
                    Answer=read.next().charAt(0);
                    }else{
                         System.out.println(" Student with ID "
                        + idNum + " not found ");
                          System.out.println(" Press c to continue and Try again... ");
                          read.next();
                          Answer = 'y';
                    }
                     
                    }while(Answer =='Y' || Answer =='y');
                    break;
                    
                //Print All Student Details In List
                case 9: 
                    for (int i=0; i < list.listSize(); i++){
                      idNum = (int) list.getStudent(i).getIdNum();
                      list.printStudentDetails(idNum);
                       System.out.println("***************************************************************************");
                    }
                    System.out.println(" Press c to continue... ");
                          read.next();
                    break;
                    
                    //about method
                    case 10:
                        about();
                    break;
                    
                //Exit Program
                case 0: 
                    System.exit(0);
                    break;
                    //Wrong number typed in
                default:
                    System.out.println("Number Not Found...Please Try Again...Select Number On Menu  ");
        }
            
        }while(number !=0);
        }
}

    

